function [w2] = minL2(X, y)
w2 = X\y;